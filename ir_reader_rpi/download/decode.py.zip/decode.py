import json
import argparse

p = argparse.ArgumentParser()
p.add_argument("-t", "--time", help="Base Time", required=True, type=int)
p.add_argument("-f", "--file", help="Filename", required=True)
p.add_argument("id", nargs="+", type=str, help="IR codes")

args = p.parse_args()

# 16進数変換
def hexadecimal(l):
  target = iter(l)
  new_list = []

  for h, i, j, k in zip(target, target, target, target):
    new_list.append(format(h*8 + i*4 + j*2 + k, "X"))
  return new_list

# 2進数変換
def binary(l):
  target = iter(list(filter(lambda x: x <= 3, l)))
  new_list = []

  for i, j in zip(target, target):
    if i + j == 2:
      new_list.append(0)
    else:
      new_list.append(1)
  return new_list

# T単位変換
def normalize(l):
  new_list = [x//args.time for x in l]
  return new_list

# デコード
def decode(l):
  t = normalize(l)
  print("T: "+ str(t))
  bina = binary(t)
  print("bin: " + str(bina))
  hexa = hexadecimal(bina)
  print("hex: " + str(hexa))


with open(args.file, "r") as f:
  records = json.load(f)

for arg in args.id:
  if arg in records:
    code = records[arg]

    decode(code)

